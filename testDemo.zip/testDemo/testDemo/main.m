//
//  main.m
//  testDemo
//
//  Created by 正浩 on 2017/12/14.
//  Copyright © 2017年 Rannie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
