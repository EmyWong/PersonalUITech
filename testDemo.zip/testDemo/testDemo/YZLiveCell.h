//
//  YZLiveCell.h
//  YZLiveApp
//
//  Created by yz on 16/8/29.
//  Copyright © 2016年 yz. All rights reserved.
//

#import <UIKit/UIKit.h>
@class YZLiveItem;
@interface YZLiveCell : UITableViewCell
@property (nonatomic, strong) YZLiveItem *live;
@end
