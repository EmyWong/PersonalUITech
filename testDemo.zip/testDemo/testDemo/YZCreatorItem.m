//
//  YZCreatorItem.m
//  YZLiveApp
//
//  Created by yz on 16/8/29.
//  Copyright © 2016年 yz. All rights reserved.
//

#import "YZCreatorItem.h"

@implementation YZCreatorItem
- (NSString *)description {
    return [NSString stringWithFormat:@"nick:%@,portrait:%@",self.nick,self.portrait];
}
@end
