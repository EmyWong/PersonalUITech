//
//  YZLiveItem.m
//  YZLiveApp
//
//  Created by yz on 16/8/29.
//  Copyright © 2016年 yz. All rights reserved.
//

#import "YZLiveItem.h"

@implementation YZLiveItem
-(NSString *)description {
    return [NSString stringWithFormat:@"city:%@,online_user:%lu,stream_addr:%@,creator:%@",self.city,(unsigned long)self.online_users,self.stream_addr,self.creator];
    
}
@end
